<?php
/**
 * Trip Packing API Routes
 * 
 * Handles packing list management for trips
 * 
 * @version 1.0.0
 */

use App\Services\AuthService;
use App\Models\TripPacking;

// Make sure required classes are loaded
require_once dirname(__DIR__, 2) . '/app/models/TripPacking.php';

/**
 * Main route handler for trip packing endpoints
 */
function handleTripPackingRoute($method, $pathParts) {
    // Check authentication for all routes
    if (!AuthService::isAuthenticated()) {
        Response::unauthorized('Authentication required');
    }
    
    // Path should be: api/trips/{tripId}/packing-list/...
    if (count($pathParts) < 3 || $pathParts[1] !== 'packing-list') {
        Response::error('Invalid packing route', 400);
    }
    
    $tripId = (int)$pathParts[0];
    if (!$tripId) {
        Response::error('Invalid trip ID', 400);
    }
    
    // Remove trip ID and "packing-list" from path parts
    $subPath = array_slice($pathParts, 2);
    
    try {
        switch ($method) {
            case 'GET':
                if (empty($subPath)) {
                    // GET /trips/{tripId}/packing-list
                    getPackingList($tripId);
                } elseif ($subPath[0] === 'progress') {
                    // GET /trips/{tripId}/packing-list/progress
                    getPackingProgress($tripId);
                } else {
                    Response::notFound('Endpoint not found');
                }
                break;
                
            case 'POST':
                if (empty($subPath)) {
                    Response::methodNotAllowed();
                } elseif ($subPath[0] === 'custom') {
                    // POST /trips/{tripId}/packing-list/custom
                    addCustomItem($tripId);
                } elseif ($subPath[0] === 'bulk') {
                    // POST /trips/{tripId}/packing-list/bulk
                    bulkUpdateItems($tripId);
                } else {
                    Response::notFound('Endpoint not found');
                }
                break;
                
            case 'PATCH':
            case 'PUT':
                if (count($subPath) < 2) {
                    Response::error('Item ID required', 400);
                }
                
                if ($subPath[0] === 'gear') {
                    // PATCH /trips/{tripId}/packing-list/gear/{gearId}
                    $gearId = (int)$subPath[1];
                    updateGearPackedState($tripId, $gearId);
                } elseif ($subPath[0] === 'custom') {
                    // PATCH /trips/{tripId}/packing-list/custom/{itemId}
                    $itemId = (int)$subPath[1];
                    updateCustomItem($tripId, $itemId);
                } else {
                    Response::notFound('Endpoint not found');
                }
                break;
                
            case 'DELETE':
                if (count($subPath) < 2 || $subPath[0] !== 'custom') {
                    Response::error('Custom item ID required', 400);
                }
                // DELETE /trips/{tripId}/packing-list/custom/{itemId}
                $itemId = (int)$subPath[1];
                deleteCustomItem($tripId, $itemId);
                break;
                
            default:
                Response::methodNotAllowed();
        }
    } catch (Exception $e) {
        error_log('Trip packing error: ' . $e->getMessage());
        
        // Handle specific error types
        if (strpos($e->getMessage(), 'not found') !== false || 
            strpos($e->getMessage(), 'access denied') !== false) {
            Response::notFound($e->getMessage());
        } elseif (strpos($e->getMessage(), 'authenticated') !== false) {
            Response::unauthorized($e->getMessage());
        } elseif (strpos($e->getMessage(), 'must be') !== false || 
                  strpos($e->getMessage(), 'Invalid') !== false) {
            Response::validationError(['error' => $e->getMessage()]);
        } else {
            Response::serverError('An error occurred while processing your request');
        }
    }
}

/**
 * Get complete packing list for a trip
 */
function getPackingList($tripId) {
    try {
        $packingList = TripPacking::getPackingList($tripId);
        Response::success($packingList);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get packing progress summary for a trip
 */
function getPackingProgress($tripId) {
    try {
        $progress = TripPacking::getProgress($tripId);
        Response::success($progress);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Add a custom item to the packing list
 */
function addCustomItem($tripId) {
    try {
        $data = get_request_data();
        
        // Validate required fields
        if (empty($data['item_name'])) {
            Response::validationError(['item_name' => 'Item name is required']);
        }
        
        $item = TripPacking::addCustomItem(
            $tripId,
            $data['item_name'],
            $data['category'] ?? 'main',
            $data['quantity'] ?? 1,
            $data['notes'] ?? null
        );
        
        Response::success($item, 201);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Update packed state for a gear item
 */
function updateGearPackedState($tripId, $gearId) {
    try {
        if (!$gearId) {
            Response::error('Invalid gear ID', 400);
        }
        
        $data = get_request_data();
        
        if (!isset($data['is_packed'])) {
            Response::validationError(['is_packed' => 'Packed state is required']);
        }
        
        $success = TripPacking::upsertPackedState(
            $tripId,
            $gearId,
            (bool)$data['is_packed']
        );
        
        Response::success(['success' => $success]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Update a custom item
 */
function updateCustomItem($tripId, $itemId) {
    try {
        if (!$itemId) {
            Response::error('Invalid item ID', 400);
        }
        
        $data = get_request_data();
        
        if (empty($data)) {
            Response::validationError(['error' => 'No fields to update']);
        }
        
        $success = TripPacking::updateCustomItem($tripId, $itemId, $data);
        
        Response::success(['success' => $success]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Delete a custom item
 */
function deleteCustomItem($tripId, $itemId) {
    try {
        if (!$itemId) {
            Response::error('Invalid item ID', 400);
        }
        
        $success = TripPacking::deleteCustomItem($tripId, $itemId);
        
        Response::success(['success' => $success]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Bulk update packed states
 */
function bulkUpdateItems($tripId) {
    try {
        $data = get_request_data();
        
        if (!isset($data['items']) || !is_array($data['items'])) {
            Response::validationError(['items' => 'Items array is required']);
        }
        
        $success = TripPacking::bulkSetPacked($tripId, $data['items']);
        
        Response::success(['success' => $success]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Helper to get request data
 */
function get_request_data() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    
    if (strpos($contentType, 'application/json') !== false) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            Response::error('Invalid JSON', 400);
        }
        
        return $data ?? [];
    }
    
    // Fall back to POST/PUT data
    return $_POST;
}
