/**
 * BttApi Client
 * Centralized API client for all AJAX operations
 */

window.BttApi = {
    baseUrl: window.BTT ? window.BTT.apiUrl : '/BTT/ajax-handler.php',
    
    // Generic request handler
    request: async function(route, method = 'GET', data = null, options = {}) {
        const url = `${this.baseUrl}?route=${route}${options.id ? '&id=' + options.id : ''}`;
        
        const fetchOptions = {
            method: method,
            credentials: 'include',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        
        if (data && method !== 'GET') {
            if (data instanceof FormData) {
                fetchOptions.body = data;
            } else {
                fetchOptions.headers['Content-Type'] = 'application/json';
                fetchOptions.body = JSON.stringify(data);
            }
        }
        
        try {
            const response = await fetch(url, fetchOptions);
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || 'Request failed');
            }
            
            return result;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },
    
    // Backpacks API
    backpacks: {
        list: function() {
            return BttApi.request('backpacks');
        },
        
        get: function(id) {
            return BttApi.request('backpacks', 'GET', null, { id });
        },
        
        create: function(data) {
            return BttApi.request('backpacks', 'POST', data);
        },
        
        update: function(id, data) {
            return BttApi.request('backpacks', 'PUT', data, { id });
        },
        
        delete: function(id) {
            return BttApi.request('backpacks', 'DELETE', null, { id });
        }
    },
    
    // Gear API
    gear: {
        list: function() {
            return BttApi.request('gear');
        },
        
        create: function(data) {
            return BttApi.request('gear', 'POST', data);
        },
        
        update: function(id, data) {
            return BttApi.request('gear', 'PUT', data, { id });
        },
        
        delete: function(id) {
            return BttApi.request('gear', 'DELETE', null, { id });
        }
    }
};