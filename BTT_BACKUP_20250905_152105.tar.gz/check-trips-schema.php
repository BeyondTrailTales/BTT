<?php
require_once 'app/bootstrap.php';

try {
    $db = new PDO('sqlite:' . BTT_SQLITE_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get the actual schema of the trips table
    $stmt = $db->query("PRAGMA table_info(trips)");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Current trips table schema:\n";
    echo str_repeat("-", 80) . "\n";
    printf("%-4s %-20s %-15s %-10s %-10s %s\n", "CID", "Name", "Type", "NotNull", "Default", "PK");
    echo str_repeat("-", 80) . "\n";
    
    foreach ($columns as $col) {
        printf("%-4s %-20s %-15s %-10s %-10s %s\n", 
            $col['cid'], 
            $col['name'], 
            $col['type'], 
            $col['notnull'] ? 'YES' : 'NO', 
            $col['dflt_value'] ?? 'NULL', 
            $col['pk'] ? 'YES' : 'NO'
        );
    }
    
    echo "\n\nSearching for photo-related columns:\n";
    $photo_columns = array_filter($columns, function($col) {
        return stripos($col['name'], 'photo') !== false || stripos($col['name'], 'image') !== false;
    });
    
    if (empty($photo_columns)) {
        echo "WARNING: No photo-related columns found!\n";
    } else {
        foreach ($photo_columns as $col) {
            echo "- {$col['name']} ({$col['type']})\n";
        }
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}