<?php
require_once 'app/bootstrap.php';

try {
    $db = new PDO('sqlite:' . BTT_SQLITE_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Testing direct photo_path update...\n\n";
    
    // Get a trip to test with
    $stmt = $db->query("SELECT id, title, photo_path, photo_alt_text FROM trips WHERE user_id = 1 LIMIT 1");
    $trip = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$trip) {
        echo "No trips found for user_id = 1\n";
        exit;
    }
    
    echo "Found trip:\n";
    echo "ID: {$trip['id']}\n";
    echo "Title: {$trip['title']}\n";
    echo "Current photo_path: " . ($trip['photo_path'] ?? 'NULL') . "\n";
    echo "Current photo_alt_text: " . ($trip['photo_alt_text'] ?? 'NULL') . "\n\n";
    
    // Test 1: Direct UPDATE with hardcoded values
    echo "Test 1: Direct UPDATE with hardcoded values\n";
    $test_path = 'test_photo_' . time() . '.jpg';
    $test_alt = 'Test alt text ' . time();
    
    $sql = "UPDATE trips SET photo_path = :path, photo_alt_text = :alt WHERE id = :id";
    $stmt = $db->prepare($sql);
    $result = $stmt->execute([
        ':path' => $test_path,
        ':alt' => $test_alt,
        ':id' => $trip['id']
    ]);
    
    echo "Update result: " . ($result ? 'SUCCESS' : 'FAILED') . "\n";
    echo "Rows affected: " . $stmt->rowCount() . "\n\n";
    
    // Verify the update
    $stmt = $db->prepare("SELECT photo_path, photo_alt_text FROM trips WHERE id = ?");
    $stmt->execute([$trip['id']]);
    $updated = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "After update:\n";
    echo "photo_path: " . ($updated['photo_path'] ?? 'NULL') . "\n";
    echo "photo_alt_text: " . ($updated['photo_alt_text'] ?? 'NULL') . "\n\n";
    
    // Test 2: Using Database class
    echo "Test 2: Using Database class\n";
    require_once 'api/classes/Database.php';
    $dbClass = Database::getInstance();
    
    $test_path2 = 'test_photo_class_' . time() . '.jpg';
    $test_alt2 = 'Test alt text class ' . time();
    
    $updateData = [
        'photo_path' => $test_path2,
        'photo_alt_text' => $test_alt2,
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    $result = $dbClass->update('trips', $updateData, 'id = :id', ['id' => $trip['id']]);
    echo "Database class update result: " . ($result ? 'SUCCESS' : 'FAILED') . "\n\n";
    
    // Verify again
    $updated2 = $dbClass->fetchOne("SELECT photo_path, photo_alt_text FROM trips WHERE id = :id", ['id' => $trip['id']]);
    
    echo "After Database class update:\n";
    echo "photo_path: " . ($updated2['photo_path'] ?? 'NULL') . "\n";
    echo "photo_alt_text: " . ($updated2['photo_alt_text'] ?? 'NULL') . "\n\n";
    
    // Test 3: Check column types
    echo "Test 3: Checking column types\n";
    $stmt = $db->query("PRAGMA table_info(trips)");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        if (stripos($col['name'], 'photo') !== false) {
            echo "Column: {$col['name']} - Type: {$col['type']} - NotNull: {$col['notnull']} - Default: " . ($col['dflt_value'] ?? 'NULL') . "\n";
        }
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}