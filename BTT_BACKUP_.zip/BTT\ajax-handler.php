<?php
/**
 * Direct AJAX Handler - Bypasses complex API to avoid timeouts
 * This handles backpack CRUD operations directly with SQLite
 */

// Clean all output buffers and start fresh
while (ob_get_level()) {
    ob_end_clean();
}
ob_start();

require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/helpers/achievement_helper.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    header('Content-Type: application/json');
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Set headers early
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Connect directly to SQLite
$db = new PDO('sqlite:' . __DIR__ . '/storage/sqlite/btt.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA foreign_keys = ON');

$user_id = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

// Handle method override for FormData requests (from BTTApi.put and BTTApi.delete)
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper($_POST['_method']);
}

$route = $_GET['route'] ?? '';
$id = $_GET['id'] ?? null;

// Debug logging (only to error log, not output)
if (defined('BTT_DEBUG') && BTT_DEBUG) {
    error_log("AJAX Handler: User=$user_id, Method=$method, Route=$route, ID=$id");
}

// Check if required tables exist and create them if not
try {
    $tables = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
    
    if (!in_array('backpacks', $tables)) {
        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Creating missing backpacks table");
        $db->exec("
            CREATE TABLE backpacks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                capacity_l INTEGER DEFAULT 65,
                weight_empty_g INTEGER DEFAULT 0,
                type VARCHAR(50) DEFAULT 'custom',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }
    
    if (!in_array('backpack_gear', $tables)) {
        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Creating missing backpack_gear table");
        $db->exec("
            CREATE TABLE backpack_gear (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                backpack_id INTEGER NOT NULL,
                gear_id INTEGER DEFAULT NULL,
                custom_name VARCHAR(255) NOT NULL,
                custom_weight INTEGER DEFAULT 0,
                custom_category VARCHAR(100) DEFAULT 'other',
                quantity INTEGER DEFAULT 1,
                section VARCHAR(100) DEFAULT 'main',
                position INTEGER DEFAULT 0,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }
    
    if (!in_array('user_gear', $tables)) {
        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Creating missing user_gear table");
        $db->exec("
            CREATE TABLE user_gear (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100) NOT NULL,
                weight_g INTEGER DEFAULT 0,
                notes TEXT,
                tags TEXT,
                deleted_at DATETIME NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }
    
    if (!in_array('trips', $tables)) {
        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Creating missing trips table");
        $db->exec("
            CREATE TABLE trips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title VARCHAR(255) NOT NULL,
                location VARCHAR(255),
                start_date DATE,
                end_date DATE,
                description TEXT,
                trip_type VARCHAR(50),
                distance REAL DEFAULT 0,
                distance_unit VARCHAR(10) DEFAULT 'miles',
                elevation_gain REAL DEFAULT 0,
                difficulty VARCHAR(50),
                favorite INTEGER DEFAULT 0,
                completed INTEGER DEFAULT 0,
                backpack_id INTEGER,
                photo_path VARCHAR(500),
                photo_alt_text VARCHAR(500),
                permit_required INTEGER DEFAULT 0,
                permit_cost REAL,
                permit_info TEXT,
                trailhead_parking VARCHAR(255),
                parking_cost REAL,
                cell_coverage VARCHAR(50),
                crowd_level VARCHAR(50),
                water_sources TEXT,
                trail_conditions TEXT,
                pre_trip_notes TEXT,
                post_trip_notes TEXT,
                lessons_learned TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }
} catch (Exception $e) {
    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Error checking/creating tables: " . $e->getMessage());
}

// Check if backpack_gear table has gear_id column and add it if missing
try {
    $columns = $db->query("PRAGMA table_info(backpack_gear)")->fetchAll(PDO::FETCH_ASSOC);
    $hasGearId = false;
    foreach ($columns as $col) {
        if ($col['name'] === 'gear_id') {
            $hasGearId = true;
            break;
        }
    }
    
    if (!$hasGearId) {
        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Adding missing gear_id column to backpack_gear table");
        $db->exec("ALTER TABLE backpack_gear ADD COLUMN gear_id INTEGER DEFAULT NULL");
    }
} catch (Exception $e) {
    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Error checking gear_id column: " . $e->getMessage());
}

// Helper function to get icon for category
function getIcon($category) {
    $icons = [
        'shelter' => '⛺',
        'sleep' => '🛌',
        'cooking' => '🔥',
        'water' => '💧',
        'clothing' => '👕',
        'navigation' => '🗺️',
        'hygiene' => '🧼',
        'first-aid' => '🏥',
        'electronics' => '📱',
        'food' => '🍔',
        'footwear' => '👟',
        'repair' => '🔧',
        'other' => '📦',
        'tools' => '🔧',
        'pack' => '🎒'
    ];
    return $icons[$category] ?? '📦';
}

try {
    // Handle gear library
    if ($route === 'gear') {
        if ($method === 'GET') {
            // Return gear in the expected format for GearManager
            $stmt = $db->prepare("
                SELECT * FROM user_gear 
                WHERE user_id = ? AND (deleted_at IS NULL OR deleted_at = '') 
                ORDER BY category, name
            ");
            $stmt->execute([$user_id]);
            $userGear = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Load default gear from gear-default.json file
            $gearJsonFile = __DIR__ . '/assets/data/gear-default.json';
            $defaultGear = [];
            
            if (file_exists($gearJsonFile)) {
                $jsonContent = file_get_contents($gearJsonFile);
                $gearData = json_decode($jsonContent, true);
                
                if (isset($gearData['items']) && is_array($gearData['items'])) {
                    $defaultGear = $gearData['items'];
                }
            }
            
            // Combine all gear sources  
            $gear = [];
            
            // Add user gear first
            foreach ($userGear as $item) {
                $gear[] = [
                    'id' => $item['id'],
                    'name' => $item['name'],
                    'category' => $item['category'],
                    'weight_g' => (int)($item['weight_g'] ?? 0),
                    'notes' => $item['notes'] ?? '',
                    'tags' => !empty($item['tags']) ? (is_string($item['tags']) ? explode(',', $item['tags']) : $item['tags']) : [],
                    'is_default' => false,
                    'is_custom' => true
                ];
            }
            
            // Add default gear if we don't have much custom gear
            if (count($gear) < 50 && !empty($defaultGear)) {
                foreach ($defaultGear as $item) {
                    $gear[] = [
                        'id' => 'def-' . ($item['id'] ?? uniqid()),
                        'name' => $item['name'],
                        'category' => $item['category'],
                        'weight_g' => (int)($item['weight_g'] ?? 0),
                        'notes' => $item['notes'] ?? '',
                        'tags' => $item['tags'] ?? [],
                        'is_default' => true,
                        'is_custom' => false
                    ];
                }
            }
            
            // Return the gear items directly (GearManager.js expects array or object with success/data)
            ob_clean();
            echo json_encode($gear);
            exit;
        }
        
        if ($method === 'POST') {
            // Create new gear item
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (empty($data['name']) || empty($data['category'])) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Name and category are required']);
                exit;
            }
            
            $stmt = $db->prepare("
                INSERT INTO user_gear (user_id, name, category, weight_g, notes, tags, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            ");
            
            $tags = isset($data['tags']) && is_array($data['tags']) ? implode(',', $data['tags']) : (string)($data['tags'] ?? '');
            
            $stmt->execute([
                $user_id,
                $data['name'],
                $data['category'],
                (float)($data['weight_g'] ?? 0),
                $data['notes'] ?? '',
                $tags
            ]);
            
            $itemId = $db->lastInsertId();
            
            ob_clean();
            echo json_encode([
                'success' => true,
                'data' => [
                    'id' => $itemId,
                    'name' => $data['name'],
                    'category' => $data['category'],
                    'weight_g' => (float)($data['weight_g'] ?? 0),
                    'notes' => $data['notes'] ?? '',
                    'tags' => is_array($data['tags']) ? $data['tags'] : []
                ],
                'message' => 'Gear item created successfully'
            ]);
            exit;
        }
        
        if ($method === 'PUT') {
            // Update gear item
            if (!$id) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'ID required']);
                exit;
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $db->prepare("
                UPDATE user_gear 
                SET name = ?, category = ?, weight_g = ?, notes = ?, tags = ?, updated_at = datetime('now')
                WHERE id = ? AND user_id = ?
            ");
            
            $tags = isset($data['tags']) && is_array($data['tags']) ? implode(',', $data['tags']) : (string)($data['tags'] ?? '');
            
            $stmt->execute([
                $data['name'] ?? '',
                $data['category'] ?? '',
                (float)($data['weight_g'] ?? 0),
                $data['notes'] ?? '',
                $tags,
                $id,
                $user_id
            ]);
            
            ob_clean();
            echo json_encode([
                'success' => true,
                'message' => 'Gear item updated successfully'
            ]);
            exit;
        }
        
        if ($method === 'DELETE') {
            // Delete gear item
            if (!$id) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'ID required']);
                exit;
            }
            
            $stmt = $db->prepare("DELETE FROM user_gear WHERE id = ? AND user_id = ?");
            $stmt->execute([$id, $user_id]);
            
            ob_clean();
            echo json_encode([
                'success' => true,
                'message' => 'Gear item deleted successfully'
            ]);
            exit;
        }
    }
    
    // Handle trips
    if ($route === 'trips') {
        try {
            if ($method === 'GET') {
                if ($id) {
                    // Get single trip
                    $stmt = $db->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
                    $stmt->execute([$id, $user_id]);
                    $trip = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    ob_clean();
                    echo json_encode($trip ?: ['success' => false, 'message' => 'Trip not found']);
                    exit;
                } else {
                    // Get all trips
                    $stmt = $db->prepare("SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC");
                    $stmt->execute([$user_id]);
                    $trips = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    ob_clean();
                    echo json_encode($trips);
                    exit;
                }
            }
        } catch (Exception $e) {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            exit;
        }
        
        if ($method === 'POST') {
            try {
                // Create new trip - handle both FormData and JSON input
                $rawInput = file_get_contents('php://input');
                $data = json_decode($rawInput, true);
                
                // If JSON decode failed, try $_POST (for FormData)
                if ($data === null && !empty($_POST)) {
                    $data = $_POST;
                }
                
                if (empty($data['title'])) {
                    ob_clean();
                    echo json_encode(['success' => false, 'message' => 'Title is required']);
                    exit;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO trips (
                        user_id, title, location, start_date, end_date, description, 
                        trip_type, distance, distance_unit, elevation_gain, difficulty,
                        favorite, completed, backpack_id, photo_path, photo_alt_text,
                        permit_required, permit_cost, permit_info, trailhead_parking, parking_cost,
                        cell_coverage, crowd_level, water_sources, trail_conditions,
                        pre_trip_notes, post_trip_notes, lessons_learned, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                ");
                
                $stmt->execute([
                    $user_id,
                    $data['title'],
                    $data['location'] ?? '',
                    $data['start_date'] ?? null,
                    $data['end_date'] ?? null,
                    $data['description'] ?? '',
                    $data['trip_type'] ?? null,
                    (float)($data['distance'] ?? 0),
                    $data['distance_unit'] ?? 'miles',
                    (float)($data['elevation_gain'] ?? 0),
                    $data['difficulty'] ?? null,
                    (int)($data['favorite'] ?? 0),
                    (int)($data['completed'] ?? 0),
                    !empty($data['backpack_id']) ? (int)$data['backpack_id'] : null,
                    $data['photo_path'] ?? null,
                    $data['photo_alt_text'] ?? null,
                    (int)($data['permit_required'] ?? 0),
                    !empty($data['permit_cost']) ? (float)$data['permit_cost'] : null,
                    $data['permit_info'] ?? null,
                    $data['trailhead_parking'] ?? null,
                    !empty($data['parking_cost']) ? (float)$data['parking_cost'] : null,
                    $data['cell_coverage'] ?? null,
                    $data['crowd_level'] ?? null,
                    $data['water_sources'] ?? null,
                    $data['trail_conditions'] ?? null,
                    $data['pre_trip_notes'] ?? null,
                    $data['post_trip_notes'] ?? null,
                    $data['lessons_learned'] ?? null
                ]);
                
                $tripId = $db->lastInsertId();
                
                // Return created trip
                $stmt = $db->prepare("SELECT * FROM trips WHERE id = ?");
                $stmt->execute([$tripId]);
                $trip = $stmt->fetch(PDO::FETCH_ASSOC);
                
                ob_clean();
                echo json_encode($trip);
                exit;
            } catch (Exception $e) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to create trip: ' . $e->getMessage()]);
                exit;
            }
        }
        
        if ($method === 'PUT') {
            try {
                // Update trip
                if (!$id) {
                    ob_clean();
                    echo json_encode(['success' => false, 'message' => 'ID required']);
                    exit;
                }
                
                // Handle both FormData and JSON input
                $rawInput = file_get_contents('php://input');
                $data = json_decode($rawInput, true);
                
                // If JSON decode failed, try $_POST (for FormData)
                if ($data === null && !empty($_POST)) {
                    $data = $_POST;
                    // Remove the _method field from data
                    unset($data['_method']);
                }
                
                // Build dynamic UPDATE query based on provided fields
                $updateFields = [];
                $updateValues = [];
                
                $allowedFields = [
                    'title', 'location', 'start_date', 'end_date', 'description',
                    'trip_type', 'distance', 'distance_unit', 'elevation_gain', 'difficulty',
                    'favorite', 'completed', 'backpack_id', 'photo_path', 'photo_alt_text',
                    'permit_required', 'permit_cost', 'permit_info', 'trailhead_parking', 'parking_cost',
                    'cell_coverage', 'crowd_level', 'water_sources', 'trail_conditions',
                    'pre_trip_notes', 'post_trip_notes', 'lessons_learned'
                ];
                
                foreach ($allowedFields as $field) {
                    if (array_key_exists($field, $data)) {
                        $updateFields[] = "$field = ?";
                        
                        // Handle different field types
                        if (in_array($field, ['favorite', 'completed', 'permit_required'])) {
                            $updateValues[] = (int)$data[$field];
                        } elseif (in_array($field, ['distance', 'elevation_gain', 'permit_cost', 'parking_cost'])) {
                            $updateValues[] = $data[$field] !== '' ? (float)$data[$field] : null;
                        } elseif ($field === 'backpack_id') {
                            $updateValues[] = !empty($data[$field]) ? (int)$data[$field] : null;
                        } else {
                            $updateValues[] = $data[$field];
                        }
                    }
                }
                
                if (empty($updateFields)) {
                    ob_clean();
                    echo json_encode(['success' => false, 'message' => 'No fields to update']);
                    exit;
                }
                
                $updateFields[] = "updated_at = datetime('now')";
                
                $stmt = $db->prepare("
                    UPDATE trips 
                    SET " . implode(', ', $updateFields) . "
                    WHERE id = ? AND user_id = ?
                ");
                
                $updateValues[] = $id;
                $updateValues[] = $user_id;
                
                $stmt->execute($updateValues);
                
                // Return updated trip
                $stmt = $db->prepare("SELECT * FROM trips WHERE id = ?");
                $stmt->execute([$id]);
                $trip = $stmt->fetch(PDO::FETCH_ASSOC);
                
                ob_clean();
                echo json_encode($trip);
                exit;
            } catch (Exception $e) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to update trip: ' . $e->getMessage()]);
                exit;
            }
        }
        
        if ($method === 'DELETE') {
            try {
                // Delete trip
                if (!$id) {
                    ob_clean();
                    echo json_encode(['success' => false, 'message' => 'ID required']);
                    exit;
                }
                
                $stmt = $db->prepare("DELETE FROM trips WHERE id = ? AND user_id = ?");
                $stmt->execute([$id, $user_id]);
                
                ob_clean();
                echo json_encode([
                    'success' => true,
                    'message' => 'Trip deleted successfully'
                ]);
                exit;
            } catch (Exception $e) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to delete trip: ' . $e->getMessage()]);
                exit;
            }
        }
    }
    
    // Handle backpack operations
    if ($route === 'backpacks') {
        
        switch ($method) {
            case 'GET':
                if ($id) {
                    // Get single backpack
                    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Getting single backpack ID=$id for user=$user_id");
                    $stmt = $db->prepare("SELECT * FROM backpacks WHERE id = ? AND user_id = ?");
                    $stmt->execute([$id, $user_id]);
                    $pack = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Get items for this backpack
                    if ($pack) {
                        $stmt = $db->prepare("SELECT * FROM backpack_gear WHERE backpack_id = ? ORDER BY section, position");
                        $stmt->execute([$id]);
                        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Found " . count($items) . " items for backpack $id");
                        
                        // Organize items into sections
                        $sections = [];
                        $sectionNames = [
                            'main' => 'Main Pack',
                            'worn' => 'Worn Items',
                            'consumables' => 'Consumables',
                            'emergency' => 'Emergency Kit',
                            'electronics' => 'Electronics',
                            'cooking' => 'Cooking Gear',
                            'shelter' => 'Shelter System'
                        ];
                        
                        $sectionIcons = [
                            'main' => '🎒',
                            'worn' => '👕',
                            'consumables' => '🍎',
                            'emergency' => '🚨',
                            'electronics' => '📱',
                            'cooking' => '🍳',
                            'shelter' => '🏕️'
                        ];
                        
                        foreach ($items as $item) {
                            $section = $item['section'] ?? 'main';
                            if (!isset($sections[$section])) {
                                $sections[$section] = [
                                    'id' => $section,
                                    'name' => $sectionNames[$section] ?? ucfirst($section),
                                    'icon' => $sectionIcons[$section] ?? '📦',
                                    'items' => [],
                                    'collapsed' => false
                                ];
                            }
                            $sections[$section]['items'][] = [
                                'id' => $item['id'],
                                'gear_id' => $item['gear_id'],
                                'name' => $item['custom_name'] ?? 'Unknown',
                                'weight_g' => $item['custom_weight'] ?? 0,
                                'quantity' => $item['quantity'] ?? 1,
                                'category' => $item['custom_category'] ?? 'other',
                                'notes' => $item['notes'] ?? '',
                                'worn' => (bool)($item['worn'] ?? false),
                                'consumable' => (bool)($item['consumable'] ?? false)
                            ];
                        }
                        
                        // Ensure main section exists even if empty
                        if (!isset($sections['main'])) {
                            $sections['main'] = [
                                'id' => 'main',
                                'name' => 'Main Pack',
                                'items' => []
                            ];
                        }
                        
                        $pack['sections'] = array_values($sections);
                        $pack['items'] = $items; // Also include raw items for compatibility
                    } else {
                        if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Backpack $id not found for user $user_id");
                    }
                    
                    ob_clean();
                    echo json_encode($pack ?: ['success' => false, 'message' => 'Backpack not found']);
                    exit;
                } else {
                    // Get all backpacks
                    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Getting all backpacks for user=$user_id");
                    $stmt = $db->prepare("SELECT * FROM backpacks WHERE user_id = ? ORDER BY created_at DESC");
                    $stmt->execute([$user_id]);
                    $packs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Found " . count($packs) . " backpacks for user=$user_id");
                    
                    // Calculate actual weight and item count for each pack
                    foreach ($packs as &$pack) {
                        $stmt = $db->prepare("SELECT SUM(custom_weight * quantity) as total_weight, SUM(quantity) as total_items FROM backpack_gear WHERE backpack_id = ?");
                        $stmt->execute([$pack['id']]);
                        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        $pack['total_weight_g'] = ($pack['weight_empty_g'] ?? 0) + ($stats['total_weight'] ?? 0);
                        $pack['total_items'] = $stats['total_items'] ?? 0;
                        $pack['trip_count'] = 0; // TODO: Add trip count if needed
                    }
                    
                    if (defined('BTT_DEBUG') && BTT_DEBUG) error_log("AJAX Handler: Returning " . count($packs) . " processed backpacks");
                    // Clean any remaining output and return JSON
                    ob_clean();
                    echo json_encode($packs);
                    exit;
                }
                break;
                
            case 'POST':
                // Create new backpack
                $data = json_decode(file_get_contents('php://input'), true);
                
                if (empty($data['name'])) {
                    echo json_encode(['success' => false, 'message' => 'Name is required']);
                    exit;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO backpacks (user_id, name, description, capacity_l, weight_empty_g, type, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                ");
                
                $stmt->execute([
                    $user_id,
                    $data['name'],
                    $data['description'] ?? '',
                    $data['capacity_l'] ?? 65,
                    $data['weight_empty_g'] ?? 0,
                    $data['type'] ?? 'custom'
                ]);
                
                $packId = $db->lastInsertId();
                
                // Save sections and items if provided
                if (isset($data['sections']) && is_array($data['sections'])) {
                    $position = 0;
                    foreach ($data['sections'] as $sectionIndex => $section) {
                        if (isset($section['items']) && is_array($section['items'])) {
                            foreach ($section['items'] as $itemIndex => $item) {
                                // Check if we need to add missing columns
                                try {
                                    $stmt = $db->prepare("
                                        INSERT INTO backpack_gear 
                                        (backpack_id, gear_id, custom_name, custom_weight, custom_category, quantity, section, position, notes, worn, consumable) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $packId,
                                        $item['gear_id'] ?? null,
                                        $item['name'] ?? 'Unknown',
                                        $item['weight_g'] ?? 0,
                                        $item['category'] ?? 'other',
                                        $item['quantity'] ?? 1,
                                        $section['id'] ?? 'main',
                                        $position++,
                                        $item['notes'] ?? '',
                                        isset($item['worn']) && $item['worn'] ? 1 : 0,
                                        isset($item['consumable']) && $item['consumable'] ? 1 : 0
                                    ]);
                                } catch (PDOException $e) {
                                    // If columns are missing, try without them
                                    $stmt = $db->prepare("
                                        INSERT INTO backpack_gear 
                                        (backpack_id, custom_name, custom_weight, custom_category, quantity, section, position) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $packId,
                                        $item['name'] ?? 'Unknown',
                                        $item['weight_g'] ?? 0,
                                        $item['category'] ?? 'other',
                                        $item['quantity'] ?? 1,
                                        $section['id'] ?? 'main',
                                        $position++
                                    ]);
                                }
                            }
                        }
                    }
                }
                
                // Check for achievements
                $achievementContext = [
                    'action' => 'backpack_created',
                    'pack_id' => $packId,
                    'pack_weight' => isset($data['base_weight']) ? $data['base_weight'] : null,
                    'item_count' => isset($data['sections']) ? count($data['sections']) : 0
                ];
                $earnedAchievements = check_achievements_safe($user_id, $achievementContext, $db);
                
                // Return created pack
                $stmt = $db->prepare("SELECT * FROM backpacks WHERE id = ?");
                $stmt->execute([$packId]);
                $pack = $stmt->fetch(PDO::FETCH_ASSOC);
                
                ob_clean();
                echo json_encode([
                    'success' => true,
                    'data' => $pack,
                    'message' => 'Backpack created successfully',
                    'achievements' => $earnedAchievements
                ]);
                exit;
                break;
                
            case 'PUT':
                // Update backpack
                if (!$id) {
                    echo json_encode(['success' => false, 'message' => 'ID required']);
                    exit;
                }
                
                $data = json_decode(file_get_contents('php://input'), true);
                
                $stmt = $db->prepare("
                    UPDATE backpacks 
                    SET name = ?, description = ?, updated_at = datetime('now')
                    WHERE id = ? AND user_id = ?
                ");
                
                $stmt->execute([
                    $data['name'] ?? '',
                    $data['description'] ?? '',
                    $id,
                    $user_id
                ]);
                
                // Clear existing items
                $db->prepare("DELETE FROM backpack_gear WHERE backpack_id = ?")->execute([$id]);
                
                // Save new items
                if (isset($data['sections']) && is_array($data['sections'])) {
                    $position = 0;
                    foreach ($data['sections'] as $sectionIndex => $section) {
                        if (isset($section['items']) && is_array($section['items'])) {
                            foreach ($section['items'] as $itemIndex => $item) {
                                try {
                                    // Try with all columns first
                                    $stmt = $db->prepare("
                                        INSERT INTO backpack_gear 
                                        (backpack_id, gear_id, custom_name, custom_weight, custom_category, quantity, section, position, notes, worn, consumable) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $id,
                                        $item['gear_id'] ?? null,
                                        $item['name'] ?? 'Unknown',
                                        $item['weight_g'] ?? 0,
                                        $item['category'] ?? 'other',
                                        $item['quantity'] ?? 1,
                                        $section['id'] ?? 'main',
                                        $position++,
                                        $item['notes'] ?? '',
                                        isset($item['worn']) && $item['worn'] ? 1 : 0,
                                        isset($item['consumable']) && $item['consumable'] ? 1 : 0
                                    ]);
                                } catch (PDOException $e) {
                                    // Fallback if columns don't exist
                                    $stmt = $db->prepare("
                                        INSERT INTO backpack_gear 
                                        (backpack_id, gear_id, custom_name, custom_weight, custom_category, quantity, section, position) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $id,
                                        $item['gear_id'] ?? null,
                                        $item['name'] ?? 'Unknown',
                                        $item['weight_g'] ?? 0,
                                        $item['category'] ?? 'other',
                                        $item['quantity'] ?? 1,
                                        $section['id'] ?? 'main',
                                        $position++
                                    ]);
                                }
                            }
                        }
                    }
                }
                
                // Calculate pack weight and check achievements
                $stmt = $db->prepare("
                    SELECT SUM(custom_weight * quantity) as total_weight, COUNT(*) as item_count
                    FROM backpack_gear 
                    WHERE backpack_id = ?
                ");
                $stmt->execute([$id]);
                $packStats = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $achievementContext = [
                    'action' => 'pack_updated',
                    'pack_id' => $id,
                    'pack_weight' => $packStats['total_weight'] / 1000, // Convert to kg
                    'item_count' => $packStats['item_count']
                ];
                $earnedAchievements = check_achievements_safe($user_id, $achievementContext, $db);
                
                // Return updated pack
                $stmt = $db->prepare("SELECT * FROM backpacks WHERE id = ?");
                $stmt->execute([$id]);
                $pack = $stmt->fetch(PDO::FETCH_ASSOC);
                
                ob_clean();
                echo json_encode([
                    'success' => true,
                    'data' => $pack,
                    'message' => 'Backpack updated successfully',
                    'achievements' => $earnedAchievements
                ]);
                exit;
                break;
                
            case 'DELETE':
                if (!$id) {
                    echo json_encode(['success' => false, 'message' => 'ID required']);
                    exit;
                }
                
                // Delete items first
                $db->prepare("DELETE FROM backpack_gear WHERE backpack_id = ?")->execute([$id]);
                
                // Delete backpack
                $stmt = $db->prepare("DELETE FROM backpacks WHERE id = ? AND user_id = ?");
                $stmt->execute([$id, $user_id]);
                
                ob_clean();
                echo json_encode([
                    'success' => true,
                    'message' => 'Backpack deleted successfully'
                ]);
                exit;
                break;
        }
    }
    
    // Handle individual backpack gear items
    if ($route === 'backpack-gear') {
        if ($method === 'POST') {
            // Add item to backpack
            $backpack_id = $_POST['backpack_id'] ?? null;
            $custom_name = $_POST['custom_name'] ?? '';
            $custom_weight = intval($_POST['custom_weight'] ?? 0);
            $custom_category = $_POST['custom_category'] ?? 'other';
            $quantity = intval($_POST['quantity'] ?? 1);
            $section = $_POST['section'] ?? 'main';
            $gear_id = $_POST['gear_id'] ?? null;
            $notes = $_POST['notes'] ?? '';
            
            if (!$backpack_id || !$custom_name) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                exit;
            }
            
            // Verify backpack belongs to user
            $stmt = $db->prepare("SELECT id FROM backpacks WHERE id = ? AND user_id = ?");
            $stmt->execute([$backpack_id, $user_id]);
            if (!$stmt->fetch()) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Backpack not found']);
                exit;
            }
            
            // Insert item
            $stmt = $db->prepare("
                INSERT INTO backpack_gear (backpack_id, custom_name, custom_weight, custom_category, quantity, section, gear_id, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$backpack_id, $custom_name, $custom_weight, $custom_category, $quantity, $section, $gear_id, $notes]);
            
            // Update backpack's updated_at timestamp
            $stmt = $db->prepare("UPDATE backpacks SET updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$backpack_id]);
            
            ob_clean();
            echo json_encode(['success' => true, 'item_id' => $db->lastInsertId()]);
            exit;
            
        } elseif ($method === 'DELETE') {
            // Remove item from backpack
            $item_id = $_GET['item_id'] ?? null;
            $backpack_id = $_GET['backpack_id'] ?? null;
            
            if (!$item_id || !$backpack_id) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Missing item_id or backpack_id']);
                exit;
            }
            
            // Verify backpack belongs to user and item exists
            $stmt = $db->prepare("
                DELETE FROM backpack_gear 
                WHERE id = ? AND backpack_id IN (SELECT id FROM backpacks WHERE id = ? AND user_id = ?)
            ");
            $stmt->execute([$item_id, $backpack_id, $user_id]);
            
            if ($stmt->rowCount() > 0) {
                // Update backpack's updated_at timestamp
                $stmt = $db->prepare("UPDATE backpacks SET updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmt->execute([$backpack_id]);
                
                ob_clean();
                echo json_encode(['success' => true]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Item not found']);
            }
            exit;
        }
    }
    
    // If no route matched, return error
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Unknown route: ' . $route
    ]);
    exit;
    
} catch (Exception $e) {
    // Clean any output buffer before error response
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
    exit;
}

// This should never be reached due to explicit exits above
if (!headers_sent()) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'No matching route found'
    ]);
    exit;
}
